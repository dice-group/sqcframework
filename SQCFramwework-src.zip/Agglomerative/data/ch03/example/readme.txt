Synthetic data set with the following characteristics:

 - All users like comedy and suspence (Some Like It Hot, Groundhog Day)
 - Only male users like Moulin Rouge, When Harry Met Sally, The Wedding Date
 - Only femail users like action movies: Riddick, Matrix, Usual Suspects, Alien, Bourn Identity, Resident Evil, Die Hard

